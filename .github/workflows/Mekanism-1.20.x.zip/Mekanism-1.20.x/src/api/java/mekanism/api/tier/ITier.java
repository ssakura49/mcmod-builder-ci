package mekanism.api.tier;

public interface ITier {

    /**
     * Gets the base tier version of this tiered object.
     */
    BaseTier getBaseTier();
}